package com.dhenlux.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "dhenlux_ring3";
    private static final long[] BUZZ = new long[] {0, 1500, 600, 1500, 600, 1500, 600, 1500};

    private static Uri chimeUri(Context ctx) {
        return Uri.parse("android.resource://" + ctx.getPackageName() + "/raw/chime");
    }

    private static void ensureChannel(Context ctx) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CHANNEL) != null) {
                return;
            }
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Pickup alarm ring", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Rings like an alarm for pickup reminders");
            ch.enableVibration(true);
            ch.setVibrationPattern(BUZZ);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            ensureChannel(ctx);
            int id = intent.getIntExtra("id", 1);
            String title = intent.getStringExtra("title");
            String body = intent.getStringExtra("body");
            String key = intent.getStringExtra("key");
            if (title == null) {
                title = "Dhenlux";
            }
            if (body == null) {
                body = "";
            }
            Intent open = new Intent(ctx, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            if (key != null && key.length() > 0) {
                open.putExtra("dhenlux_key", key);
            }
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                f |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(ctx, id, open, f);
            int icon = ctx.getResources().getIdentifier("ic_stat_dhenlux", "drawable", ctx.getPackageName());
            if (icon == 0) {
                icon = ctx.getApplicationInfo().icon;
            }
            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(0xFF0B7A75)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setTimeoutAfter(60000);
            if (android.os.Build.VERSION.SDK_INT < 26) {
                b.setVibrate(BUZZ);
            }
            Notification n = b.build();
            n.flags |= Notification.FLAG_INSISTENT;
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(id, n);
            playMarimba(ctx);
        } catch (Exception ignored) {
        }
    }

    // Plays res/raw/chime.wav on the alarm stream so phone brands cannot swap the sound.
    private void playMarimba(Context ctx) {
        final PendingResult pr = goAsync();
        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable done = new Runnable() {
            boolean fin = false;
            @Override
            public void run() {
                if (!fin) {
                    fin = true;
                    try {
                        pr.finish();
                    } catch (Exception ignored) {
                    }
                }
            }
        };
        try {
            int rid = ctx.getResources().getIdentifier("chime", "raw", ctx.getPackageName());
            AssetFileDescriptor afd = ctx.getResources().openRawResourceFd(rid);
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    m.release();
                    done.run();
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    m.release();
                    done.run();
                    return true;
                }
            });
            mp.prepare();
            mp.start();
            h.postDelayed(done, 9000);
        } catch (Exception e) {
            done.run();
        }
    }
}
