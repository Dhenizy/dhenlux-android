package com.dhenlux.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.AlarmClock;

import org.json.JSONArray;
import org.json.JSONObject;

public class ClockAlarms {
    private static final String PREF = "dhenlux_clock";
    private static final String KEY = "done";

    public static int apply(Activity act, JSONArray alarms) throws Exception {
        SharedPreferences sp = act.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String done = sp.getString(KEY, "");
        long now = System.currentTimeMillis();
        int made = 0;
        StringBuilder keep = new StringBuilder();
        for (int i = 0; i < alarms.length() && made < 8; i++) {
            JSONObject o = alarms.getJSONObject(i);
            long at = o.getLong("at");
            if (at < now + 5000 || at > now + 86400000L) {
                continue;
            }
            String tag = o.getInt("id") + "_" + at + ";";
            if (done.contains(tag)) {
                continue;
            }
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(at);
            Intent it = new Intent(AlarmClock.ACTION_SET_ALARM);
            it.putExtra(AlarmClock.EXTRA_HOUR, c.get(java.util.Calendar.HOUR_OF_DAY));
            it.putExtra(AlarmClock.EXTRA_MINUTES, c.get(java.util.Calendar.MINUTE));
            it.putExtra(AlarmClock.EXTRA_MESSAGE, o.optString("message", "Dhenlux pickup"));
            it.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(it);
            keep.append(tag);
            made++;
        }
        String[] old = done.split(";");
        for (String t : old) {
            int u = t.indexOf('_');
            if (u > 0) {
                try {
                    long at = Long.parseLong(t.substring(u + 1));
                    if (at > now) {
                        keep.append(t).append(";");
                    }
                } catch (Exception ignored) {
                }
            }
        }
        sp.edit().putString(KEY, keep.toString()).apply();
        return made;
    }
}
