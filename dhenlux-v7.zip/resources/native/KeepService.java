package com.dhenlux.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

public class KeepService extends Service {
    private static final String CH = "dhenlux_keep";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "Alarms active", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Keeps Dhenlux pickup alarms running");
                nm.createNotificationChannel(ch);
            }
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                f |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(this, 7001, new Intent(this, MainActivity.class), f);
            int icon = getResources().getIdentifier("ic_stat_dhenlux", "drawable", getPackageName());
            if (icon == 0) {
                icon = getApplicationInfo().icon;
            }
            Notification n = new NotificationCompat.Builder(this, CH)
                .setSmallIcon(icon)
                .setContentTitle("Dhenlux alarms active")
                .setContentText("Pickup alarms are being kept running")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                startForeground(7001, n, 1073741824);
            } else {
                startForeground(7001, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        AlarmStore.reschedule(this);
        super.onTaskRemoved(rootIntent);
    }
}
