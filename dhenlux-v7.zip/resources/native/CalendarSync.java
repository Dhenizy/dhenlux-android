package com.dhenlux.app;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import org.json.JSONArray;
import org.json.JSONObject;

public class CalendarSync {
    private static final String PREF = "dhenlux_cal";

    private static long pickCalendar(ContentResolver cr) {
        Cursor c = null;
        try {
            c = cr.query(
                CalendarContract.Calendars.CONTENT_URI,
                new String[] {CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY},
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= 500 AND " + CalendarContract.Calendars.VISIBLE + " = 1",
                null,
                null);
            long first = -1;
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    if (first < 0) {
                        first = id;
                    }
                    if (c.getInt(1) == 1) {
                        return id;
                    }
                }
            }
            return first;
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    private static void deleteEvent(ContentResolver cr, long eventId) {
        try {
            cr.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null);
        } catch (Exception ignored) {
        }
    }

    public static int apply(Context ctx, JSONArray orders) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        long calId = pickCalendar(cr);
        if (calId < 0) {
            throw new Exception("No calendar found. Open your Calendar app once and set it up.");
        }
        java.util.HashSet<String> wanted = new java.util.HashSet<String>();
        int made = 0;
        for (int i = 0; i < orders.length(); i++) {
            JSONObject o = orders.getJSONObject(i);
            String key = o.getString("key");
            wanted.add(key);
            JSONArray rem = o.getJSONArray("reminders");
            String sig = o.getLong("start") + "|" + rem.toString() + "|" + o.optString("title", "");
            String prev = sp.getString(key, "");
            if (prev.length() > 0) {
                int bar = prev.indexOf('#');
                if (bar > 0 && prev.substring(bar + 1).equals(sig)) {
                    continue;
                }
                if (bar > 0) {
                    deleteEvent(cr, Long.parseLong(prev.substring(0, bar)));
                }
            }
            ContentValues v = new ContentValues();
            v.put(CalendarContract.Events.CALENDAR_ID, calId);
            v.put(CalendarContract.Events.TITLE, o.optString("title", "Dhenlux pickup"));
            v.put(CalendarContract.Events.DESCRIPTION, o.optString("desc", ""));
            v.put(CalendarContract.Events.DTSTART, o.getLong("start"));
            v.put(CalendarContract.Events.DTEND, o.getLong("end"));
            v.put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().getID());
            v.put(CalendarContract.Events.HAS_ALARM, 1);
            Uri u = cr.insert(CalendarContract.Events.CONTENT_URI, v);
            if (u == null) {
                continue;
            }
            long eid = ContentUris.parseId(u);
            for (int k = 0; k < rem.length(); k++) {
                ContentValues r = new ContentValues();
                r.put(CalendarContract.Reminders.EVENT_ID, eid);
                r.put(CalendarContract.Reminders.MINUTES, rem.getInt(k));
                r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
                cr.insert(CalendarContract.Reminders.CONTENT_URI, r);
            }
            sp.edit().putString(key, eid + "#" + sig).apply();
            made++;
        }
        java.util.Map<String, ?> all = sp.getAll();
        for (String k : all.keySet()) {
            if (!wanted.contains(k)) {
                String prev = String.valueOf(all.get(k));
                int bar = prev.indexOf('#');
                if (bar > 0) {
                    try {
                        deleteEvent(cr, Long.parseLong(prev.substring(0, bar)));
                    } catch (Exception ignored) {
                    }
                }
                sp.edit().remove(k).apply();
            }
        }
        return made;
    }
}
