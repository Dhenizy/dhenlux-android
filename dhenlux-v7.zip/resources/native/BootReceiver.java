package com.dhenlux.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        AlarmStore.reschedule(ctx);
        try {
            if (ctx.getSharedPreferences("dhenlux_alarms", Context.MODE_PRIVATE).getBoolean("keep", false)) {
                androidx.core.content.ContextCompat.startForegroundService(ctx, new Intent(ctx, KeepService.class));
            }
        } catch (Exception ignored) {
        }
    }
}
