import fs from "fs";
const A = "android/app/src/main";
let m = fs.readFileSync(`${A}/AndroidManifest.xml`, "utf8");
const perms = ["POST_NOTIFICATIONS","SCHEDULE_EXACT_ALARM","USE_EXACT_ALARM","RECEIVE_BOOT_COMPLETED","VIBRATE","WAKE_LOCK","REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"];
let add = "";
for (const p of perms) if (!m.includes(`android.permission.${p}`)) add += `    <uses-permission android:name="android.permission.${p}" />\n`;
m = m.replace("<application", add + "    <application");
const recv = `    <receiver android:name="com.dhenlux.app.AlarmReceiver" android:exported="false" />
    <receiver android:name="com.dhenlux.app.BootReceiver" android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.BOOT_COMPLETED" />
            <action android:name="android.intent.action.QUICKBOOT_POWERON" />
            <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
        </intent-filter>
    </receiver>
`;
m = m.replace("</application>", recv + "    </application>");
fs.writeFileSync(`${A}/AndroidManifest.xml`, m);
fs.mkdirSync(`${A}/res/raw`, { recursive: true });
fs.copyFileSync("resources/chime.wav", `${A}/res/raw/chime.wav`);
fs.cpSync("resources/icons", `${A}/res`, { recursive: true });
fs.writeFileSync(`${A}/res/values/ic_launcher_background.xml`, `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B7A75</color>\n</resources>\n`);

const J = `${A}/java/com/dhenlux/app`;
fs.mkdirSync(J, { recursive: true });
for (const f of ["AlarmStore.java", "AlarmReceiver.java", "BootReceiver.java"]) {
  fs.copyFileSync(`resources/native/${f}`, `${J}/${f}`);
}
fs.writeFileSync(`${J}/DhenluxNativePlugin.java`, `package com.dhenlux.app;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.media.AudioAttributes;
import android.content.Context;
import android.provider.CalendarContract;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "DhenluxNative")
public class DhenluxNativePlugin extends Plugin {

    @PluginMethod
    public void addEvent(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_INSERT);
            i.setData(CalendarContract.Events.CONTENT_URI);
            i.putExtra(CalendarContract.Events.TITLE, call.getString("title", ""));
            i.putExtra(CalendarContract.Events.DESCRIPTION, call.getString("description", ""));
            i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, call.getData().getLong("begin"));
            i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, call.getData().getLong("end"));
            i.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, call.getBoolean("allDay", false));
            getActivity().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("No calendar app found: " + e.getMessage());
        }
    }

    @PluginMethod
    public void createAlarmChannel(PluginCall call) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel("due2", "Pickup alarms", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Loud alarm with long vibration");
                ch.enableVibration(true);
                ch.setVibrationPattern(new long[] {0, 1500, 600, 1500, 600, 1500, 600, 1500});
                ch.setLockscreenVisibility(1);
                AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                ch.setSound(Uri.parse("android.resource://" + getContext().getPackageName() + "/raw/chime"), aa);
                nm.createNotificationChannel(ch);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("channel failed");
        }
    }

    @PluginMethod
    public void openAutoStart(PluginCall call) {
        String[][] targets = new String[][] {
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
            {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"},
            {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
            {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
            {"com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"},
            {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
            {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
            {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"}
        };
        for (String[] t : targets) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(t[0], t[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getActivity().startActivity(i);
                JSObject r = new JSObject();
                r.put("opened", "autostart");
                call.resolve(r);
                return;
            } catch (Exception ignored) {
            }
        }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
            getActivity().startActivity(i);
            JSObject r = new JSObject();
            r.put("opened", "appinfo");
            call.resolve(r);
        } catch (Exception e) {
            call.reject("Could not open settings");
        }
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        try {
            String pkg = getContext().getPackageName();
            PowerManager pm = (PowerManager) getContext().getSystemService(android.content.Context.POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(pkg)) {
                JSObject r = new JSObject();
                r.put("already", true);
                call.resolve(r);
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + pkg));
            getActivity().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open battery settings");
        }
    }

    private static String pendingKey = null;

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (intent != null && intent.hasExtra("dhenlux_key")) {
            pendingKey = intent.getStringExtra("dhenlux_key");
        }
    }

    @PluginMethod
    public void getLaunchKey(PluginCall call) {
        JSObject r = new JSObject();
        String k = pendingKey;
        pendingKey = null;
        if (k == null && getActivity() != null) {
            Intent it = getActivity().getIntent();
            if (it != null && it.hasExtra("dhenlux_key")) {
                k = it.getStringExtra("dhenlux_key");
                it.removeExtra("dhenlux_key");
            }
        }
        if (k != null && k.length() > 0) {
            r.put("key", k);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void scheduleAlarms(PluginCall call) {
        try {
            JSArray arr = call.getArray("alarms");
            if (arr == null) {
                arr = new JSArray();
            }
            int n = AlarmStore.apply(getContext(), arr, call.getBoolean("append", false));
            JSObject r = new JSObject();
            r.put("count", n);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("Alarm schedule failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openAppInfo(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
            getActivity().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open app settings");
        }
    }

    @PluginMethod
    public void saveFile(PluginCall call) {
        try {
            String name = call.getString("name", "orders.csv");
            String data = call.getString("data", "");
            byte[] bytes = data.getBytes("UTF-8");
            JSObject r = new JSObject();
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContext().getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) {
                    call.reject("Could not create file");
                    return;
                }
                java.io.OutputStream os = getContext().getContentResolver().openOutputStream(u);
                os.write(bytes);
                os.close();
                r.put("where", "Downloads");
            } else {
                java.io.File dir = getContext().getExternalFilesDir(null);
                java.io.File f = new java.io.File(dir, name);
                java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                fo.write(bytes);
                fo.close();
                r.put("where", f.getAbsolutePath());
            }
            call.resolve(r);
        } catch (Exception e) {
            call.reject("Save failed: " + e.getMessage());
        }
    }
}
`);
fs.writeFileSync(`${J}/MainActivity.java`, `package com.dhenlux.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(DhenluxNativePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
console.log("Android project patched");
