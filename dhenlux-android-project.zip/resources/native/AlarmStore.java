package com.dhenlux.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmStore {
    private static final String PREF = "dhenlux_alarms";
    private static final String KEY = "list";

    private static int flags() {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            f |= PendingIntent.FLAG_IMMUTABLE;
        }
        return f;
    }

    private static PendingIntent ringIntent(Context ctx, JSONObject o) throws Exception {
        Intent i = new Intent(ctx, AlarmReceiver.class);
        i.setAction("com.dhenlux.app.RING");
        i.putExtra("id", o.getInt("id"));
        i.putExtra("title", o.optString("title", "Dhenlux"));
        i.putExtra("body", o.optString("body", ""));
        i.putExtra("key", o.optString("key", ""));
        return PendingIntent.getBroadcast(ctx, o.getInt("id"), i, flags());
    }

    private static void setOne(Context ctx, AlarmManager am, JSONObject o) throws Exception {
        PendingIntent show = PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class), flags());
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(o.getLong("at"), show), ringIntent(ctx, o));
    }

    public static int apply(Context ctx, JSONArray fresh, boolean append) throws Exception {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
        JSONArray kept = new JSONArray();
        long now = System.currentTimeMillis();
        if (append) {
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (o.getLong("at") > now) {
                    kept.put(o);
                }
            }
        } else {
            for (int i = 0; i < old.length(); i++) {
                am.cancel(ringIntent(ctx, old.getJSONObject(i)));
            }
        }
        int n = 0;
        for (int i = 0; i < fresh.length(); i++) {
            JSONObject o = fresh.getJSONObject(i);
            if (o.getLong("at") > now + 2000) {
                setOne(ctx, am, o);
                kept.put(o);
                n++;
            }
        }
        sp.edit().putString(KEY, kept.toString()).apply();
        return n;
    }

    public static void reschedule(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
            long now = System.currentTimeMillis();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (o.getLong("at") > now + 2000) {
                    setOne(ctx, am, o);
                }
            }
        } catch (Exception ignored) {
        }
    }
}
