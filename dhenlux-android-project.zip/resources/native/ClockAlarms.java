package com.dhenlux.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.AlarmClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ClockAlarms {
    private static final String PREF = "dhenlux_clock";
    private static final String KEY = "done2";

    public static int apply(Activity act, JSONArray alarms) throws Exception {
        SharedPreferences sp = act.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String done = sp.getString(KEY, "");
        long now = System.currentTimeMillis();
        String tone = ClockTone.alarmUri(act);
        int made = 0;
        StringBuilder keep = new StringBuilder();
        for (int i = 0; i < alarms.length() && made < 10; i++) {
            JSONObject o = alarms.getJSONObject(i);
            JSONArray days = o.optJSONArray("days");
            boolean repeat = days != null && days.length() > 0;
            long at = o.optLong("at", 0);
            long exp = o.optLong("exp", at);
            if (!repeat && (at < now + 5000 || at > now + 86400000L)) {
                continue;
            }
            if (repeat && exp < now) {
                continue;
            }
            String tag = o.getInt("id") + "_" + o.optString("sig", String.valueOf(at));
            if (done.contains(";" + tag + "@")) {
                continue;
            }
            Intent it = new Intent(AlarmClock.ACTION_SET_ALARM);
            if (repeat) {
                it.putExtra(AlarmClock.EXTRA_HOUR, o.getInt("hour"));
                it.putExtra(AlarmClock.EXTRA_MINUTES, o.getInt("minute"));
                ArrayList<Integer> dl = new ArrayList<Integer>();
                for (int k = 0; k < days.length(); k++) {
                    dl.add(days.getInt(k));
                }
                it.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, dl);
            } else {
                java.util.Calendar c = java.util.Calendar.getInstance();
                c.setTimeInMillis(at);
                it.putExtra(AlarmClock.EXTRA_HOUR, c.get(java.util.Calendar.HOUR_OF_DAY));
                it.putExtra(AlarmClock.EXTRA_MINUTES, c.get(java.util.Calendar.MINUTE));
            }
            it.putExtra(AlarmClock.EXTRA_MESSAGE, o.optString("message", "Dhenlux pickup"));
            it.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            it.putExtra(AlarmClock.EXTRA_VIBRATE, true);
            if (tone != null) {
                it.putExtra(AlarmClock.EXTRA_RINGTONE, tone);
            }
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(it);
            keep.append(";").append(tag).append("@").append(exp);
            made++;
        }
        String[] old = done.split(";");
        for (String t : old) {
            int a = t.lastIndexOf('@');
            if (a > 0) {
                try {
                    long e = Long.parseLong(t.substring(a + 1));
                    if (e > now) {
                        keep.append(";").append(t);
                    }
                } catch (Exception ignored) {
                }
            }
        }
        sp.edit().putString(KEY, keep.toString()).apply();
        return made;
    }
}
