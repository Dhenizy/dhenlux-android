package com.dhenlux.app;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.InputStream;
import java.io.OutputStream;

public class ClockTone {

    private static String install(Context ctx, String fileName, String rawName, String folder, String flagColumn, String title) {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            return null;
        }
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            Cursor c = cr.query(
                coll,
                new String[] {MediaStore.Audio.Media._ID},
                MediaStore.MediaColumns.DISPLAY_NAME + " = ?",
                new String[] {fileName},
                null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        return ContentUris.withAppendedId(coll, c.getLong(0)).toString();
                    }
                } finally {
                    c.close();
                }
            }
            int res = ctx.getResources().getIdentifier(rawName, "raw", ctx.getPackageName());
            if (res == 0) {
                return null;
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/x-wav");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
            v.put(MediaStore.Audio.Media.TITLE, title);
            v.put(flagColumn, 1);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(coll, v);
            if (u == null) {
                return null;
            }
            InputStream in = ctx.getResources().openRawResource(res);
            OutputStream os = cr.openOutputStream(u);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
            }
            os.close();
            in.close();
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
            return u.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public static String alarmUri(Context ctx) {
        return install(ctx, "dhenlux_alarm.wav", "dhenlux_alarm", Environment.DIRECTORY_ALARMS, MediaStore.Audio.Media.IS_ALARM, "Dhenlux alarm");
    }

    public static String chimeUri(Context ctx) {
        return install(ctx, "dhenlux_chime.wav", "chime", Environment.DIRECTORY_NOTIFICATIONS, MediaStore.Audio.Media.IS_NOTIFICATION, "Dhenlux chime");
    }
}
